#include "C2-matrix.h"

void loadMatrix (int array[DIM][DIM]) {
    for (int fila = 0; fila < DIM; fila++)
        for (int columna = 0; columna < DIM; columna++)
            array[fila][columna] = fila*columna;
}

void showMatrix (int array[DIM][DIM]) {
    for (int fila = 0; fila < DIM; fila++) {
        printf("[ ");
        for (int columna = 0; columna < DIM; columna++)
           printf("%i ", array[fila][columna]);
        printf("]\n");
    }
}

void scalarProduct (int scalar, int array[DIM][DIM]) {
    for (int fila = 0; fila < DIM; fila++)
        for (int columna = 0; columna < DIM; columna++)
            array[fila][columna] = scalar*array[fila][columna];
}

void add (int array[DIM][DIM], int array1[DIM][DIM], int array2[DIM][DIM]) {
    for (int fila = 0; fila < DIM; fila++)
        for (int columna = 0; columna < DIM; columna++)
            array[fila][columna] = array1[fila][columna]+array2[fila][columna];
}

void multiply (int array[DIM][DIM], int array1[DIM][DIM], int array2[DIM][DIM]) {
    for (int fila = 0; fila < DIM; fila++)
        for (int columna = 0; columna < DIM; columna++) {
            int suma = 0;
            for (int i = 0; i < DIM; i++){
                suma = suma + array1[fila][i]*array2[i][columna];
            }
            array[fila][columna] = suma;
        }
}
