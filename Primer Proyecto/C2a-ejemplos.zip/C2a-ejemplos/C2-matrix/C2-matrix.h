#ifndef C2_MATRIX_h
#define C2_MATRIX_h

#include <stdio.h>
#include "constants.h"

void loadMatrix (int array[DIM][DIM]);
void showMatrix (int array[DIM][DIM]);
void scalarProduct (int scalar, int array[DIM][DIM]);
void add (int array[DIM][DIM], int array1[DIM][DIM], int array2[DIM][DIM]);
void multiply (int array[DIM][DIM], int array1[DIM][DIM], int array2[DIM][DIM]);

#endif /* C2_MATRIX_h */
