#ifndef CONSTANTS_h
#define CONSTANTS_h

#define DIM 5

#endif /* CONSTANTS_h */
